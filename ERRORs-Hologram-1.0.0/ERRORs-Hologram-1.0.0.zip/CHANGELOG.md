# Version 1.2.4
- Fixed bug where loading into another map would break hologram for the rest of the game session.

# Version 1.2.3
- Made it so only the actual hologram follows your hand
- Changed Button Positions

# Version 1.2.2
- Fixed README
- Fixed Version number being wrong for ModUI

# Version 1.2.1
- Added the ability to upload your own obj files in the UserData Folder

# Version 1.1.1
- Added Toggability to the Hologram via ModUI
- Added the ability to move the hologram with ModUI
- Made it so you can only spin the Hologram if you are close to it

# Version 1.1.0
- Refactored most code to be cleaner
- Added Back Button
- Added Animated Perlin Noise Model
- Moved Models To Custom Class
- Added Helper functions instead of making multiple versions of the same code
- Made them spheres instead of cubes (will be an option in a later update)
- Fixed README

# Version 1.0.0
- Created


# Help And Other Resources
Get help and find other resources in the Modding Discord:
https://discord.gg/fsbcnZgzfa